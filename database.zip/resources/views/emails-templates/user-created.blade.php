<!DOCTYPE html>
<html>

<head>
    <title>Bienvenido</title>
</head>

<body>
    <h1>Bienvenido a Tesoria</h1>

    <p>Tu cuenta ha sido creada exitosamente.</p>

    <p>A continuación, se te proporciona la información de acceso:</p>

    <p>Correo electrónico: {{ $email }}</p>
    <p>Contraseña: {{ $password }}</p>

    <p>
        Por favor, guarda esta información de forma segura.
    </p>
</body>

</html>
