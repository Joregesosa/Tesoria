<!DOCTYPE html>
<html>
<head>
    <title>Nuevo documento Recibido</title>
</head>
<body>
    <h1>Has recibido un nuevo documento en la solicitud:</h1>
    <p style="color: #3d3dfa">No: {{ $numero_solicitud }}</p>
    <p>Puedes visualizarlo en el panel de solicitudes.</p>
    <p>¡Gracias por usar nuestra aplicación!</p>
</body>
</html>